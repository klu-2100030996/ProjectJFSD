package com.klef.jfsd.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.model.Employee;
import com.klef.jfsd.springboot.model.EmployeeCustomerMapping;
import com.klef.jfsd.springboot.repository.AdminRepository;
import com.klef.jfsd.springboot.repository.CustomerRepository;
import com.klef.jfsd.springboot.repository.EmployeeCustomerMappingRepository;
import com.klef.jfsd.springboot.repository.EmployeeRepository;

@Service
public class AdminServiceImpl implements AdminService
{
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
    private EmployeeRepository employeeRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	
	
	@Autowired
	   private EmployeeCustomerMappingRepository employeecustomermappingRepository;
	
	
	
	@Override
	public List<Employee> viewallemps() 
	{
		return employeeRepository.findAll();
	}

	@Override
	public Employee viewempbyid(int eid) 
	{

    Optional<Employee> obj =  employeeRepository.findById(eid);
         
         if(obj.isPresent())
         {
           Employee emp = obj.get();
           
           return emp;
         }
         else
         {
           return null;
         }

	}

	@Override
	public String deleteemp(int eid) 
	{
		Optional<Employee> obj =  employeeRepository.findById(eid);
		   
		   String msg = null;
		   
		   if(obj.isPresent())
		   {
			   Employee emp = obj.get();
			   
			   employeeRepository.delete(emp);
			   
			   msg = "Counsellor Deleted Successfully";
		   }
		   else
		   {
			   msg = "Counsellor Not Found";
		   }
		   
		   return msg;
	}

	@Override
	public Admin checkadminlogin(String uname, String pwd)
	{
		return adminRepository.checkadminlogin(uname, pwd);
	}

	@Override
	public String addcustomer(Customer c) 
	{
		customerRepository.save(c);
		return "Student Added Successfully";
	}

	@Override
	public long employeecount() 
	{
		return employeeRepository.count();
	}

	@Override
	public long customercount() 
	{
		return customerRepository.count();
	}

	// employee active status update
	
	@Override
	public int updatestatus(int eid, boolean status) 
	{
		return adminRepository.updatestatus(eid, status);
	}
	
	
	
	
	
	@Override
	  public List<Customer> viewallstudents()
	  {
	    return customerRepository.findAll();
	  }

	  @Override
	  public List<Employee> viewallcounsellors() 
	  {
	    return employeeRepository.findAll();
	  }

	  @Override
	  public Employee employeeybyid(int eid) 
	  {
	    return employeeRepository.findById(eid).get();
	  }

	  @Override
	  public Customer customerbyid(int cid) 
	  {
	    return customerRepository.findById(cid).get();
	  }

	  @Override
	  public String employeecustomermapping(EmployeeCustomerMapping ecm)
	  {
	    employeecustomermappingRepository.save(ecm);
	    return "Mapping Done";
	  }

	  @Override
	  public List<EmployeeCustomerMapping> viewEmployeeCustomerMappings() 
	  {
	    return (List<EmployeeCustomerMapping>) employeecustomermappingRepository.findAll();
	  }

	  @Override
	  public long checkecustomermapping(Employee e, Customer c) 
	  {
	    return employeecustomermappingRepository.checkecustomermapping(e, c);
	  }

}
