package com.klef.jfsd.springboot.service;

import java.util.List;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.model.Employee;
import com.klef.jfsd.springboot.model.EmployeeCustomerMapping;

public interface AdminService 
{
  public List<Employee> viewallemps();
  public Employee viewempbyid(int eid);
  public String deleteemp(int eid);
  public Admin checkadminlogin(String uname,String pwd);
  
  public String addcustomer(Customer c);
  public long employeecount();  // count(*)
  public long customercount();  // count(*)
  public int updatestatus(int eid,boolean status);
  
  
  
  
  public List<Customer> viewallstudents();
  public List<Employee> viewallcounsellors();
  
  
  
  
  public Employee employeeybyid(int eid);
  public Customer customerbyid(int cid);
  
  public String employeecustomermapping(EmployeeCustomerMapping ecm);
  public List<EmployeeCustomerMapping> viewEmployeeCustomerMappings();
  
  public long checkecustomermapping(Employee e,Customer c);
}
