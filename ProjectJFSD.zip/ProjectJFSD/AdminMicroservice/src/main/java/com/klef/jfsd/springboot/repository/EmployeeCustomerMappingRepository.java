package com.klef.jfsd.springboot.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.model.Employee;
import com.klef.jfsd.springboot.model.EmployeeCustomerMapping;

public interface EmployeeCustomerMappingRepository extends CrudRepository<EmployeeCustomerMapping, Integer>
{

	@Query("SELECT COUNT(ecm) FROM EmployeeCustomerMapping ecm where ecm.employee = ?1 and ecm.customer = ?2")
	  public long checkecustomermapping(Employee employee,Customer customer);
	
}
